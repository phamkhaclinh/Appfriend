﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;

using System.Threading;

namespace Appfriend
{
    public partial class Form1 : Form
    {
        public static IWebDriver driver = new ChromeDriver();

        public Form1()
        {

            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            driver.Url = "https://www.facebook.com";
            IWebElement UserName = driver.FindElement(By.Id("email"));
            IWebElement PassWord = driver.FindElement(By.Id("pass"));

            IWebElement Login_btn = driver.FindElement(By.Id("u_0_l"));

            UserName.SendKeys("hoangminh.le12302@gmail.com");
            PassWord.SendKeys("hoangminh12302");
            Thread.Sleep(2000);
            Login_btn.Click();
            string a = driver.Title;
            while (a == driver.Title)
            {
                Thread.Sleep(5000);
            }
            Thread.Sleep(3000);
            Waiting wt = new Waiting();
            wt.Show();
            wt.Load_datafr();
            Hide();

        }
        private void button2_Click(object sender, EventArgs e)
        {
            driver.Close();
            Close();
            //select slt = new select();
            //slt.Show();
            //Hide();

            //Application.Exit();
        }

    }
}
