﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Appfriend
{
    public partial class select : Form
    {
        public select()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            Waiting wait = new Waiting();
            wait.Show();
            wait.Load_datafr();
            Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Waiting2 wait = new Waiting2();
            wait.Show();
            wait.GetFriendRequest();
            wait.LoadRequest();
            Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void select_Load(object sender, EventArgs e)
        {

        }
    }
}
